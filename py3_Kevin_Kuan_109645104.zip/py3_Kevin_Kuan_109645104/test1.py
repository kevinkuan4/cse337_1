counter = 1

while counter <= 5:
	counter+=1
	print(counter)

print("Answer:",counter)